/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_destroy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marberna <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/12/03 15:16:32 by marberna          #+#    #+#             */
/*   Updated: 2023/12/03 15:16:38 by marberna         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush.h"
#include <stdlib.h>

void	ft_destroy(t_rush **parse, t_rush **parse_verif, char *path_to_dict)
{
	int	a;

	a = 0;
	while (parse[a])
	{
		free(parse[a]->name);
		free(parse[a]->value);
		free(parse[a]);
		a++;
	}
	free(parse);
	a = 0;
	while (parse_verif[a])
	{
		free(parse_verif[a]->name);
		free(parse_verif[a]->value);
		free(parse_verif[a]);
		a++;
	}
	free(parse_verif);
	free(path_to_dict);
}
