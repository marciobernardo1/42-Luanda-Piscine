/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marberna <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/12/03 15:23:49 by marberna          #+#    #+#             */
/*   Updated: 2023/12/03 15:23:51 by marberna         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush.h"

void	ft_putstr(char *str)
{
	int	n;

	n = 0;
	while (str[n])
		ft_putchar(str[n++]);
}

void	ft_putstr_space(char *str, int a)
{
	int	n;

	n = 0;
	while (str[n])
		ft_putchar(str[n++]);
	if (a == 0)
		ft_putchar(' ');
}
