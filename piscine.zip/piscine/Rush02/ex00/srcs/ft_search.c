/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_search.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marberna <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/12/03 15:23:56 by marberna          #+#    #+#             */
/*   Updated: 2023/12/03 15:23:58 by marberna         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush.h"
#include <stdlib.h>

t_rush	*ft_search_by_id_parse(t_rush **parse, char *id)
{
	int	i;

	i = 0;
	while (parse[i])
	{
		if (!ft_strcmp(id, parse[i]->value))
			return (parse[i]);
		i++;
	}
	return (NULL);
}

t_rush	*ft_search_by_id(t_rush **pairs, int size, char *id)
{
	int	i;

	i = 0;
	while (i < size - 1)
	{
		if (!ft_strcmp(id, pairs[i]->value))
			return (pairs[i]);
		i++;
	}
	return (NULL);
}
